import { Component } from '@angular/core';

@Component({
  selector: 'app-member-detailed',
  imports: [],
  templateUrl: './member-detailed.html',
  styleUrl: './member-detailed.css'
})
export class MemberDetailed {

}
